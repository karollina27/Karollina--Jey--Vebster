PuffCoin (PUFF)
===========

[![Build Status](https://travis-ci.org/RazorLove/puffcoin.png?branch=master)](https://travis-ci.org/RazorLove/puffcoin)


Scrypt Hashcash PoW Template